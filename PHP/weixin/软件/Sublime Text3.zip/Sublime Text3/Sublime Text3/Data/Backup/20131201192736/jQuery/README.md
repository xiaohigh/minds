# jQuery Package for Sublime Text

This is a Sublime Text bundle to help with jQuery functions.

## Authors

* Zander Martineau
* Karl Swedberg
* Jonathan Chaffer

## License

This bundle is dual-licensed under MIT and GPL licenses (just like jQuery).

* [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
* [http://www.gnu.org/licenses/gpl.html](http://www.gnu.org/licenses/gpl.html)

Use it, change it, fork it, sell it. Do what you will, but please leave the author attribution.