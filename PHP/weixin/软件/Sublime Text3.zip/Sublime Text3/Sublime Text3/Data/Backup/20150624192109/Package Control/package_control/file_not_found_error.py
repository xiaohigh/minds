class FileNotFoundError(Exception):
    """If a file is not found"""

    pass
